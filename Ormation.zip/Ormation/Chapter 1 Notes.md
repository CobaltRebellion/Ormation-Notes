## 1.4 Data Hierarchy
Bits
Characters
Fields
Records
Files
Database
Big Data
### Byte measurements

| Unit             | Bytes          | Which is Approximately              |
| ---------------- | -------------- | ----------------------------------- |
| 1 kilobyte (KB)  | 1024 bytes     | 10<sup>3</sup> (1024) bytes exactly |
| 1 megabyte (MB)  | 1024 kilobytes | 10<sup>6</sup> (1,000,000) bytes    |
| 1 gigabyte (GB)  | 1024 megabytes | 10<sup>9</sup>                      |
| 1 terabyte (TB)  | 1024 gigabytes | 10<sup>12</sup>                     |
| 1 petabyte (PB)  | 1024 terabytes | 10<sup>15</sup>                     |
| 1 exabyte (EB)   | 1024 petabytes | 10<sup>18</sup>                     |
| 1 zettabyte (ZB) | 1024 exabytes  | 10<sup>21</sup>                     |
## 1.8 Introduction to Object Technology
Classes are used to define the structure and behavior of objects, while objects are used to represent specific entities in a program.

Class to hold functions that perform that class's tasks. These functions are known as Member Functions. For example a class that represents a bank account would have a member function to deposit money, another to withdraw money, and another to query the amount of money in the account.

Just as someone has to build a car from a blueprint before you can drive the car, you must build an object from a class before a program can perform the tasks that the class's member functions define. This process is called instantiation. An object is then referred to as an instance of its class.

Object also has attributes that it carries along as it's used in the program. A bank-account object has a balance attribute that represents the amount of money in the account. Each bank-account object knows the balance in the account it represents but not the balances of the other accounts in the bank. Attributes are specified by the class's data members.