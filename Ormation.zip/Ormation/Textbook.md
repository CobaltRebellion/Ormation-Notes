7/18/2024
Got to 3.4

7/23/2024
Got to 4.10 (exclusive)

7/29/2024
Got to Chapter 6

7/30/2024
Going back to write notes, Finished chapter 2, Got to 3.2.4 (exclusive) before stopping