## 3.1
Each class created becomes a new type you can use to declare variables and create objects.

C++ is an **extensible programming language** meaning you can define new class types as needed
## 3.2

Classes cannot execute themselves

A `main` function can "drive" an object by calling its member functions--without knowing how the class is implemented. In this sense `main` is referred to as a driver program

### 3.2.1
Typically, you cannot call a member function of a class until you create an object of that class.

The line `Account myAccount;` creates an object of class Account called `myAccount`. The variables type is Account

### 3.2.2
The compiler knows about fundamental types that are built into C++

A new type that you create is known as a **user-defined** type. So the compiler does not know in advance what type Account is because it is a user-defined type.

New classes, when packaged properly, can be reused by other programmers. reusable code (such as class definition) is placed in a file known as a header that you include (via `#include`) wherever you need to use the code. By convention, a header for a user-defined type has a .h filename extension. In an `#include` directive, a user-defined header is place in double quotes (""), indicating that the header is located with your program rather than with the C++ standard library headers. An example of such is this line `#include "Account.h"`

files ending in `.cpp` are known as source-code files. You include headers into source code files, like the line above. Headers can also be included in other headers.

### 3.2.3
To call a member function for a specific object, you specify the object's name, followed by a dot operator ( . ), then the member function name and a set of parentheses. Empty parentheses indicate that the function does not require any additional information. An examples of this is here `myAccount.getName();` that example is from a longer line shown down below:
`cout << "Initial name is: " << myAccount.getName();`

A member function can return a value from the object on which the function is called.

### 3.2.4
functions that are not members a class are called global functions.

An object of C++ Standard library class string stores character string values. Class `string` is defined in the `<string>` header and belongs to namespace std.

`cin` stops reading at the first white space character.

C++ standard Library function `getline` from the `<string>` header, reads character up to, but not including a new line, which is discarded then places the characters in a string.

### 3.2.5
A member-function call can supply argument that help the function perform its task. An examples of this is shown here: `myAccount.setName(theName);`
## 3.3
A class's data members maintain data for each object of the class, and its member functions manipulate the class's data members.

Lets take a look at a class named Account.
```
#include <string>

class Account {
public:
	void setName(std::string accountName) {
		name = accountName;
	}

	std::string getName() const {
		return name;
	}
private:
	std::string name;
};

```

The class definition begins at `class Account {`. Every class definition contains the keyword class followed immediately by the the class's name.

Each object of a class has its own copy of the class's data members

An object's data members exist before a program calls member functions on a object, while they are executing, and after the member functions complete execution (look more into this)

Data members are declared inside a class definition but outside its member functions' bodies. For example name is declared in private while all the functions are in public. 

The default value for a `string` is the empty string `""`

Headers should never contain `using` directives or `using` declaration. Its why we are saying std instead of declaring it at the beginning.

A functions return type specifies the type of data the function returns to its caller after performing its task. For example the return type `void` shown the the function `setName` above, indicates that it returns nothing. 

Parameters specify additional information the function needs to perform its task, this appears in the parenthesis next to the name of the function. The `setName` function takes the parameter `accountName` of type `string`. If the parenthesis is empty, it means that it takes no parameters.

The number and order of parameters in a function call must match the number and order of parameters in the function definition's parameter list. Their type must also match.

When a program execution reaches a function's closing brace, the function returns to its caller.

Variables declared in a particular function's body are local variables, meaning that they can only be used in that function. When the function terminates, all of its local variables are lost. Function parameters are also local variables

The return statement passes a value back to the functions caller. `return name;` returns the variable name to the caller of whatever function returned that. 

A member function that does not, and should not, modify the object on which it is called is declared with const to the right of the parameter list.
`std::string getName() const {`

The keyword private is an access specifier, public is another access specifier. access specifiers are always followed by a colon (`:`) as shown here `public:` or `private:`.

Private data members are only accessible to it's class's member functions, like the function `getName()`.

Most data-member declaration are private.

Variables or functions listed in public are "available to the public", meaning that they can used by other functions in the program and by member functions of other classes. 

By default everything in a class is private unless stated otherwise.

Once you list an access specifier everything from that point has that access until you list another access specifier.

## 3.4
Each class can define a constructor for custom object initialization.

A constructor is a special member function that must have the same name as the class.

C++ requires a constructor call for every object that is created.

Like member functions, a constructor can specify parameters. The corresponding argument values help initialize the object's data members.

Normally constructors are public.

A constructor's parameter list specifies pieces of data required to initialize an object.

A constructor uses a member-initializer list to initialize its data members with the values of the corresponding parameters. This list appears between the constructors parameter list and the left brace that begins the body. The parameter list and member-initializer list is separated by a colon (`:`). Each member initializer consists of a data member's variable names followed by parentheses containing the member's initial value. Each one is separated from the next by a comma. A constructor that specifies a single parameter should be declared explicit. An example of this is shown down below.
```
explicit Account(std::string accountName)
	: name{accountName} {
	// body
}
```
If we would want to inset this into the class we made above, we would put the constructor right after `public:` on the next line.

A constructor does not specify a return type because they cannot return values.

Constructors cannot be declared `const` because initializing an object modifies it.

When you create an object, C++ calls the class's constructor to initialize the object. If a constructor has parameters, the corresponding arguments are placed in braces (`{}`) to the right of the variable name, as shown below:
`Account account1{"Jane Green"};`

When you forego the braces, C++ implicitly calls the default constructor, which always has no parameters.

## 3.5
Through the use of set and get member functions, you can validate attempted modifications to `private` date and control how that data is presented to the caller.

A client of a class is any other code that calls the class's member functions (I'm assuming this means code that doesn't belong to the class).

Client code can see a public data member and do whatever it wants with it, including setting it to an invalid value

Set functions can be programmed to validate their arguments and reject any attempts to set the data to bad values

A get function can present the data to a client in a different form. Lets say behind the curtain the value 1.25 is represented as 125, but the get function returns it as 1.25.

Tightly controlling the access to and presentation of private data can greatly reduce errors, while increasing the usability, robustness, and secuirty of your programs

## 3.6
You can initialize fundamental types data members in their declaration. An example of this shown here: `int balance{0};`. Assume this is placed right after name in the main example showed previously.

A constructor can perform validation or validity checking before modifying a data member. Lets say you want to create a new account and tell the constructor is has a negative -2 balance, the constructor, if programmed with validity checking, will reject that number and instead set it to 0. Example shown below:
```
explicit Account(std::string accountName, int initialBalance)
	: name{accountName} {

	if (initialBalance > 0) {
		balance = initialBalance;
	}
}
```
