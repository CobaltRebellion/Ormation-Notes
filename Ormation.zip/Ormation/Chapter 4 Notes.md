Goes into how you should have a plan before before writing the code. You should do this with pseudocode.

A procedure for solving a problem in terms of the **actions** to execute and the **order** in which these actions execute are called an algorithm.

All programs could be written in terms of only three control structures: The sequence structure, the selection structure, and the iteration structure.

The sequence structure is built into C++. Unless otherwise directed, the computer executes C++ statements one after the other in the order they are written; executed in sequence.

C++ has three types of selection statements. The *if* statement, the *if ... else* statement, and the *switch* statement. The if statement is a single-selection statement because it selects or ignores a single action. the if ... else statement is called a double-selection statement because it selects between two different actions. The switch statement is called a multiple-selection statement because it selects among many different actions.

C++ provides four iteration statements (sometimes called repetition statements or looping statements) that enable programs to perform statement repeatedly as long as a condition (called the loop continuation condition) remains true. These statements are as follows. The *while* statement, the *do ... while* statement, the *for* statement, and range based *for* statements. The while and for statements perform the action in their bodies 0 or more times. The do ... while statement performs the action in their body one or more times.

In C++ a decision can be based on any expression that evaluates to zero or nonzero. If zero its treated as false, if nonzero its treated as true.

The if single-selection statement performs an indicated action only when the condition in true. The if ... else double-selection statement allows you to specify an action to perform when the condition is true, and another action when the the condition is false. An example is shown below:
```
if (grade >= 60) {
	cout << "passed";
}
else {
	cout << "failed";
}
```

A program can test multiple cases by placing if ... else statements inside other if ... else statements to create nested if ... else statements. An example of this is shown below:
```
if (studentGrade >= 90) {
	cout << "A";
}
else {
	if (studentGrade >= 80) {
		cout << "B";
	}
	else {
		if (studentGrade >= 70) {
			cout << "C";
		}
		else {
			if (studentGrade >= 60) {
				cout << "D";
			}
			else {
				cout << "F";
			}
		}
	}
}
```
This can also be written instead like this:
```
if (studentGrade >= 90) {
	cout << "A";
}
else if (studentGrade >= 80) {
	cout << "B";
}
else if (studentGrade >= 70) {
	cout << "C";
}
else if (studentGrade >= 60) {
	cout << "D";
}
else {
	cout << "F";
}
```
This form avoids deep indentation of the code to the right. Such indentation often leaves little room on line of code, forcing lines to wrap.

There is also the conditional operator (`?:`) that can be used in place of an if ... else statement. This can make your code shorter and cleaner. The conditional operator is C++'s only ternary operator (an operator that takes three operands). Together, the operands and the `?:` symbol form a conditional expression. An example is shown below: (greater than or equal to 60)
```
cout << (studentGrade >= 60 ? "Passed" : "Failed");
```
Another example, that does the same thing is shown below:
```
grade >= 60 ? cout << "Passed" : cout << "Failed";
```
Conditional statements can appear in some program locations where if ... else statements cannot.

An iteration statement allows you to specify that a program should repeat an action while some condition remains true. An example of a while statement is shown below that finds the first power of 3 larger than 100.
```
int product{3};

while (product <= 100) {
	product = 3 * product;
}
```
Each iteration of the while statement multiplies product by 3, so product takes on the values 9, 27, 81, and 243 successively. When product becomes 243, product <= 100 becomes false and terminates the iteration.

Counter-controlled iteration uses a variable called a counter; or control variable to control the number of times a set of statements will execute. This is often called definite iteration, because the number of iteration is known before the loop begins executing.

Integer division results in an integer result. Any fractional part of the calculation is truncated.

Adding two integers could result in a value that's too large to store in an int variable. This known as arithmetic overflow and causes undefined behavior.

A program uses range checking to ensure that values are within a specific range. For example if a user inputs a negative number when they were instructed to only input positives, you can use range checking to check for that and tell the user their input was invalid and try again.

In sentinel-controlled iteration, a special value called a sentinel value (also called a signal value, dummy value, or a flag value) is used to indicate "end of data entry". It is often referred to as indefinite iteration because the number of iterations is not known before the loop begins executing.

Top-down, stepwise refinement is an essential tool to the development of well-structured programs. You first begin with a pseudocode representation of the **top**, a single statement that, in effect, is a complete representation of a program. Since the top rarely conveys sufficient detail form which to write a C++ program, we must refine the top into a series of smaller tasks and list these in the order in which they'll be performed, this is known as the first refinement. In the second refinement we commit to specific variables and logic (pretty much putting it into very refined pseudocode).
Top example:
```
Determine class average for the quiz
```
First refinement example:
```
Initialize variables
Input sum and count the quiz grades
Calculate and print the class average
```
Second refinement example:
```
Initialize total to zero
Initialize counter to zero

prompt user to enter the first grade
input the first grade (possibly the sentinel)

While the user has not yet inputted the sentinel
	Add this grade into the running total
	add one to the grade counter
	prompt the user to enter the next grade
	input the next grade (possibly the sentinel)

If counter is not equal to zero
	set the average to the total divided by the counter
	print the average
else
	print "no grades were entered"
```
When doing the second refinement, go statement by statement from the first refinement, it makes things much easier and less daunting. You can also do more than two refinements, you could refine this further.

The `static_cast` operator converts a temporary copy of its operand in parenthesis to the type in angle brackets. Using a cast operator in this manner is called explicit conversion. The following is an example: `double average{static_cast<double>(total) / gradeCounter};`

For arithmetic, the compiler knows how to evaluate only expressions in which the operand types are identical. To ensure this, the compiler performs an operation called promotion on selected operands.

In an expression containing values of data types `int` and `double`, C++ promotes `int` operands to `double` values.

`setprecision` is a parameterized stream manipulator (when using psm's include the header `<iomanip>`) that specifies the number of digits of precision to the right of the decimal point when a floating-point number is output. By default, floating-point values are output with six digits of precision. The stream manipulator `fixed` indicates that floating-point values should be output in fixed-point format, as opposed to scientific notation. When `fixed` and `setprecision` are used in a program, the printed value is rounded to the number of decimal positions indicated by the `setprecisions` argument, although the value in memory is unaltered.

The fundamental types are not guaranteed to be identical from computer to computer. An `int` on one machine might be represented by 16 bits of memory, on a second machine by 32 bits, and on another machine by 64 bits.

