## 2.2
---
Comments begin with `//`

Lines that begin with `#`  are processed by the preprocessor before the program is compiled, known as a preprocessing directive reprocessing directives are a message to the C++ preprocessor. For example the line `#include <iostream>` tells the preprocessor to include in the program the contents of the input/output stream header (iostream).

`main()` is part of every C++ program. C++ programs typically consist of one or more functions and classes, but *Exactly one* function in every program must be named `main`. C++ programs begin executing at `main()` even if it is not the first function defined

The line `std::cout << "Welcome to C++\n";` is a statement. Most C++ statements end with a semicolon, also known as the statement terminator. Preprocessing directives, like `#include`, do not end with a semicolon.
The `std` before `cout` is required when we use names that we've brought into the program by the preprocessing directive `#include <iostream>`. This notation specifies that we are using a name, in this case `cout`, that belongs to namespace `std`. `cin` (the standard input stream), and `cerr` (the standard error stream) also belong to this namespace. There are ways around doing this.
In the context of an output statement, the `<<` operator is referred to as the stream insertion operator. When this program executes the value to the operator's right, the right operand, is inserted into the output stream. Notice how `<<` points where the data goes.
A string literal's characters normally print exactly like how they appear between the double quotes. However there are certain characters that when combined together instead print something different, these are called escape sequences. An example of one of these is `\n`, this means newline, causing the output to move to the next line on the screen. Some common escape sequences will be shown below.

| Escape Sequence | Description                                                                                                        |
| --------------- | ------------------------------------------------------------------------------------------------------------------ |
| `\n`            | Newline. Position the screen cursor to the beginning of the next line.                                             |
| `\t`            | Horizontal tab. Move the screen cursor the the next tab stop.                                                      |
| `\r`            | Carriage return. Position the screen cursor to the beginning of the current line; do not advance to the next line. |
| `\a`            | Alert. Sound the system bell.                                                                                      |
| `\\`            | Backslash. Used to print a backslash character.                                                                    |
| `\'`            | Single quote. Used to print a single-quote character.                                                              |
| `\"`            | Double quote. Used to print a double-quote character.                                                              |

`return 0;` is one of many was to exit a function. When used at the end of main, the value `0` indicates that the program terminated successfully. According to C++ standard, if program execution reaches the end of main without encountering a return function, it is assumed that the program terminated successfully.
## 2.3
---
A single line of text can be printed in several ways, such as the example below.
```
std::cout << "Welcome ";
std::cout << "to C++!\n";
```
This is outputted as this `Welcome to C++!`. Each stream insertion resumes printing where the previous one stopped. The second insertion begins where the first one left off because the first one did not end with`\n`, nor did the second one start with `\n`.

A single statement can print multiple line by using new line characters. If you want a blank space between in your output, place 2 newline characters next to each other.
## 2.4
---
`int number1{0};` is a declaration. The identifier number1 is the name of a variable. A variable is a location in the computers memory where a value can be stored for use by a program. This declaration specifies that the variable number 1 are data of type int, meaning that it will hold integer (whole number) values, like 7, -11, and 31914. The above line also initializes number1 to 0 by placing a vale in braces immediately following the variables name. This is known as list initialization.

All variables *must* be declared with a name and data type *before* they can be used in a program. You can also declare multiple variables of the same type in one declaration by using a comma-separated list. It is suggested to not do that.

Types such as `int, double` and `char` are called fundamental types. Fundamental types consist of one or more keywords and therefore must appear in all lowercase letters.

A variable name (such as numer1) is any valid identifier that is not a keyword. An identifier is a series of characters consisting of letters, digits, and underscores ( _ )  that does *not* begin with a digit. C++ is also case sensitive so a1 and A1 are different identifiers.

Variable declarations can be places almost anywhere in a program, but they must be placed before their corresponding variables are used in the program.

The two lines below display a prompt and then the user inputs something.
```
std::cout << "Enter first integer: ";
std:cin >> number1;
```
The first line is commonly called a prompt because it directs the user to take a specific action.
The second line used the standard input stream object `cin` and the stream extraction operator `>>` to obtain a value from the keyboard. Using `>>` with `cin` takes character input from the standard input stream, which is usually the keyboard.
When the computer executes the preceding statement is wait for the user to enter a value for variable number1. The user responds by typing an integer (as characters), then pressing the enter key to send the characters to the computer. The computers converts the character representation of the number to an integer and assigns the number to the variable number1.
The user can also input invalid data, like an alphabetic character if the program was expecting an integer.

The line `std::cout << "Sum is " << sum << std::endl;` displays the variable sum after the words `Sum is ` are printed. `std::endl` is a stream manipulator. `endl` is an abbreviation for "end line". It outputs a newline and then "flushes the output buffer". What this means is that on some systems where outputs accumulate in the machine until there are enough to make it worthwhile to display them on screen, `std::endl` forces any accumulated outputs to be displayed at that moment. This can be important when the outputs are prompting the user for an action.
The statement also outputs multiple values of different types, a string and an integer (assuming sum is an integer). This is called either concatenating, chaining, or cascading stream insertion operations.
## 2.5
---
Variable names such as number1, number2, and sum actually correspond to  locations in the computers memory. Every variable has  a name, type, size, and value
## 2.6
---
Basic arithmetic stuff, refer back to chapter if needed. Follows PEMDAS for the most part, it is instead PMDRAS. {Paratheses}, {multiplication, division, remainder}, {addition, subtraction} those in brackets have the same level of precedence.. Goes from left to right if there are several operators with the same level of precedence. Exponents don't exist so you have to use multiplication (x<sup>2</sup> is `x*x`)
## 2.7
---
All about equality and relational operators. Also has the if statement.
if statements allow the program to take an alternative action based on if a condition in true or false. These conditions can be formed by using relational and equality operators (`>, <, >=, <=, ==, !=`).

These lines allow you to not use the std before `cout` and the like.
```
using std::cout;
using std::cin;
using std::endl;
```
These are known as declarations that eliminate the need to repeat the std::prefix like we showed earlier. We can also instead just use `using namespace std;` which enables a program to use *all* the names in any standard C++ header that a program may include.

The code `cin >> number1 >> number2;` gets two integers from the user (assuming number1 and number2 are integers). It uses cascaded stream extraction.

If statements look like this:
```
if (number1 == number2) {
	cout number1 << " == " << number2 << endl;
}
```
Braces are not needed around single statement bodies for if statements, only for multiple statement bodies. To avoid errors always enclose an if statements body statement(s) in braces.