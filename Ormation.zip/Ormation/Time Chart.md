7/18/2024
8:45 AM - 11:26 AM: 2 hours 41 minutes

7/23/2024
8:50 AM - 11:30 AM: 2 hours 40 minutes
7:24 PM - 9:28 PM: 2 hours 4 minutes
Total: 4 hours 44 minutes

7/25/2024
9:15 AM - 10:43

7/29/2024
8:45 AM - 10:45 AM: 2 hours

7/30/2024
8:00 AM - 12:00 AM: 4 hours

7/31/2024
8:00 AM - 10:00 AM: 2 hours

Forgot to keep track of 1-2

8/05/2024
8:00 AM - 12:00 AM: 4 hours

8/013/2024
9:00 AM -