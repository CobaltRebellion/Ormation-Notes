Essentials of Counter-Controlled Iteration:
- a control variable (or loop counter)
- the control variable's initial value
- the control variable' increment that's applied during each iteration of the loop
- the loop continuation condition that determines if looping should continue.

General format of a for statement:
```
for (initilization; loopContinuationCondition; increment) {
	statement
}
```

This format can be represented with an equivalent while statement:
```
initilization;

while (loopContinuationCondition) {
	statement;
	increment;
}
```

Sometimes a `for` statement cannot be represented with an equivalent while statement.

Typically `for` statement are used for counter-controlled iteration and `while` statements are used for sentinel-controlled iteration. However both can be used for either type.

If the initialization in the `for` header declares the control variable, it can only be used in that `for` statement. This is known as the variables scope.

All three expressions in a `for` header are optional. If the `loopContinuationCondition` is omitted, C++ assumes the loop-continuation condition is always true, creating an infinite loop.

The header of a `for` loop can also contain arithmetic.

The `do ... while` iteration statement test the loop-continuation condition after executing the loop's body; the body always executes at least once. An example is shown below:
```
do {
	cout << counter << " ";
	++counter;
} while (counter <= 10);
```

The `switch` multiple-selection statement lets you choose among several different actions based on the possible values of a variable or expression. An example is shown below:
```
switch (grade / 10) {
	case 9:
	case 10:
		++aCount;
		break;
	case 8:
		++bCount;
		break;

	case 7:
		++cCount;
		break;

	case 6:
		++dCount;
		break;

	default:
		++fCount;
		break;
}
```
What this program does is divides a grade number by 10, and then whatever that number turns into it then goes to whatever case its number corresponds to. For this we assume grade is an `int`. Lets say a grade was inputted as 85, so the switch divides it by 10 resulting in 8.5, but since grade is an int, the .5 is dropped leaving us with 8. It then jumps to case 8 and increments the `bCount` variable.

If no match occurs between the controlling expression's value and a case label, the default case executes.

The `break` statement, when executed in a `while, for, do ... while, or switch` statement causes immediate exit from that statement, it then continues execution with the first statement after the control statement. (`break` breaks out from a loop and continues with the first statement that appears outside the loop.)

The `continue` statement, when executed in a `while, for, or do ... while` statement skips the remaining statements in the loop and proceeds with the next iteration of the loop.

C++ has logical AND (`&&`) and OR (`||`) operators.

Don't confuse `==` (equality) and `=` (assignment) operators. It does not normally cause syntax errors but will give you the wrong output as they mean different things. `==` is for comparing variables and `=` is for assigning variables.

