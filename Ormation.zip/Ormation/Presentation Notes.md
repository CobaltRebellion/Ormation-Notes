device management software, Application lets you see all your devices, and deploy things to them.
Very few do immediate consistency (only one?), most do eventual consistency. None does both, kinda.